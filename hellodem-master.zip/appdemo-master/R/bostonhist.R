bostonhist <- function(variable){
	hist(Boston[[variable]], xlab=variable, main="Example plot with lazyload data")
}